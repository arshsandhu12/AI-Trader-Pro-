import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum RiskMode { safe, balanced, risk }

class SettingsService with ChangeNotifier {
  late SharedPreferences _sp;
  bool autoTrade = false;
  RiskMode riskMode = RiskMode.balanced;
  double strictness = 0.5;

  Future<void> init() async {
    _sp = await SharedPreferences.getInstance();
    autoTrade = _sp.getBool('autoTrade') ?? false;
    riskMode = RiskMode.values[_sp.getInt('riskMode') ?? 1];
    strictness = _sp.getDouble('strictness') ?? 0.5;
    notifyListeners();
  }

  void setAutoTrade(bool v) {
    autoTrade = v;
    _sp.setBool('autoTrade', v);
    notifyListeners();
  }

  void setRiskMode(RiskMode v) {
    riskMode = v;
    _sp.setInt('riskMode', v.index);
    notifyListeners();
  }

  void setStrictness(double v) {
    strictness = v;
    _sp.setDouble('strictness', v);
    notifyListeners();
  }
}
