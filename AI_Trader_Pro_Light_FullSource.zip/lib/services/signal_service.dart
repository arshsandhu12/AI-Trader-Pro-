import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/constants.dart';
import 'journal_service.dart';
import 'settings_service.dart';

class Marker {
  final double level;
  final Color color;
  final List<int> dash;
  final String label;
  Marker(this.level, this.color, this.dash, this.label);
}

class Signal {
  final String ticker;
  final String timeframe;
  final String direction; // BUY / SELL
  final double entry;
  final double stopLoss;
  final double takeProfit;
  final double confidence; // 0..100

  Signal({
    required this.ticker,
    required this.timeframe,
    required this.direction,
    required this.entry,
    required this.stopLoss,
    required this.takeProfit,
    required this.confidence,
  });

  Map<String, dynamic> toJson() => {
        'ticker': ticker,
        'timeframe': timeframe,
        'direction': direction,
        'entry': entry,
        'stopLoss': stopLoss,
        'takeProfit': takeProfit,
        'confidence': confidence,
      };
}

class SignalService with ChangeNotifier {
  final JournalService journal;
  final SettingsService settings;
  final tickerController = TextEditingController(text: "AAPL");
  String timeframe = "5m";

  List<double> currentSeries = List.generate(200, (i) => 100 + sin(i / 10) * 5 + Random().nextDouble());
  List<Marker> currentMarkers = [];
  List<Signal> signals = [];
  late SharedPreferences _sp;

  SignalService(this.journal, this.settings) {
    _init();
  }

  Future<void> _init() async {
    _sp = await SharedPreferences.getInstance();
    _loadSignalsPersisted();
  }

  void _loadSignalsPersisted() {
    // Keep simple for demo; could restore here.
  }

  void setTimeframe(String tf) {
    timeframe = tf;
    notifyListeners();
  }

  Future<void> loadData() async {
    // In full build, fetch OHLCV here (TV / broker / crypto API).
    // For demo, regenerate sample data.
    final rnd = Random();
    currentSeries = List.generate(200, (i) => 100 + sin(i / 9.0) * 6 + rnd.nextDouble());
    notifyListeners();
  }

  Future<void> scanAndSignal() async {
    // Light strategy combining a few simple heuristics; replace with ICT/FVG rules later.
    final last = currentSeries.isNotEmpty ? currentSeries.last : 100;
    final minP = currentSeries.sublist(currentSeries.length - 20).reduce(min);
    final maxP = currentSeries.sublist(currentSeries.length - 20).reduce(max);
    final mean = (minP + maxP) / 2;

    final biasUp = last > mean;
    final dir = biasUp ? "BUY" : "SELL";

    double entry = last;
    double sl = biasUp ? minP - (max(0.1, (maxP - minP) * 0.2)) : maxP + (max(0.1, (maxP - minP) * 0.2));
    double tp = biasUp ? last + (last - sl) * 1.5 : last - (sl - last) * 1.5;

    // adjust by risk mode
    switch (settings.riskMode) {
      case RiskMode.safe:
        tp = biasUp ? last + (last - sl) * 1.2 : last - (sl - last) * 1.2;
        break;
      case RiskMode.balanced:
        // keep as is
        break;
      case RiskMode.risk:
        tp = biasUp ? last + (last - sl) * 2.0 : last - (sl - last) * 2.0;
        break;
    }

    final conf = (50 + (biasUp ? 10 : 0) + (Random().nextDouble() * 20)) * (0.8 + settings.strictness * 0.4);
    final s = Signal(
      ticker: tickerController.text.trim().toUpperCase(),
      timeframe: timeframe,
      direction: dir,
      entry: entry,
      stopLoss: sl,
      takeProfit: tp,
      confidence: conf.clamp(0, 100),
    );

    // persist on chart
    currentMarkers = [
      Marker(entry, buyColor, const [2,0], "ENTRY ${entry.toStringAsFixed(2)}"),
      Marker(sl, slColor, const [6,3], "SL ${sl.toStringAsFixed(2)}"),
      Marker(tp, tpColor, const [6,3], "TP ${tp.toStringAsFixed(2)}"),
    ];
    signals.insert(0, s);

    // log to journal
    journal.logTrade({
      'ticker': s.ticker,
      'timeframe': s.timeframe,
      'direction': s.direction,
      'entry': s.entry,
      'stopLoss': s.stopLoss,
      'takeProfit': s.takeProfit,
      'rr': (s.direction == "BUY")
          ? (s.takeProfit - s.entry) / (s.entry - s.stopLoss + 1e-9)
          : (s.entry - s.takeProfit) / (s.stopLoss - s.entry + 1e-9),
      'result': '-', // to be filled by user/manual outcome
    });

    notifyListeners();
  }
}
