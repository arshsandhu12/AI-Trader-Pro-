import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class JournalService with ChangeNotifier {
  late SharedPreferences _sp;
  List<Map<String, dynamic>> trades = [];
  Stats stats = Stats.empty();

  Future<void> init() async {
    _sp = await SharedPreferences.getInstance();
    final raw = _sp.getString('trades');
    if (raw != null) {
      trades = List<Map<String, dynamic>>.from(jsonDecode(raw));
    }
    _recalc();
  }

  void logTrade(Map<String, dynamic> t) {
    trades.insert(0, t);
    _persist();
    _recalc();
  }

  void _persist() => _sp.setString('trades', jsonEncode(trades));

  void _recalc() {
    int wins = 0;
    double rrSum = 0;
    for (final t in trades) {
      final res = (t['result'] ?? '') as String;
      if (res.toLowerCase() == 'win') wins++;
      final rr = (t['rr'] ?? 0.0) as double;
      rrSum += rr;
    }
    final wr = trades.isEmpty ? 0.0 : wins * 100 / trades.length;
    final avgRR = trades.isEmpty ? 0.0 : rrSum / trades.length;
    stats = Stats(winRate: wr, avgRR: avgRR);
    notifyListeners();
  }
}

class Stats {
  final double winRate;
  final double avgRR;
  Stats({required this.winRate, required this.avgRR});
  factory Stats.empty() => Stats(winRate: 0, avgRR: 0);
}
