import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'screens/home_screen.dart';
import 'services/signal_service.dart';
import 'services/journal_service.dart';
import 'services/settings_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final settings = SettingsService();
  await settings.init();
  final journal = JournalService();
  await journal.init();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => settings),
        ChangeNotifierProvider(create: (_) => journal),
        ChangeNotifierProvider(create: (_) => SignalService(journal, settings)),
      ],
      child: const AITraderPro(),
    ),
  );
}

class AITraderPro extends StatelessWidget {
  const AITraderPro({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "AI Trader Pro",
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.greenAccent,
          brightness: Brightness.dark,
        ),
      ),
      debugShowCheckedModeBanner: false,
      home: const HomeScreen(),
    );
  }
}
