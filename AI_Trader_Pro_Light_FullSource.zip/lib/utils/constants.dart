import 'package:flutter/material.dart';
const buyColor = Colors.greenAccent;
const slColor = Colors.redAccent;
const tpColor = Colors.amber;
