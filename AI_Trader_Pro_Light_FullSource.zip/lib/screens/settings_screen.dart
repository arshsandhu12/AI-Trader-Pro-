import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/settings_service.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<SettingsService>();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text("Risk Mode", style: TextStyle(fontWeight: FontWeight.bold)),
        SegmentedButton<RiskMode>(
          segments: const [
            ButtonSegment(value: RiskMode.safe, label: Text("Safe")),
            ButtonSegment(value: RiskMode.balanced, label: Text("Balanced")),
            ButtonSegment(value: RiskMode.risk, label: Text("Risk")),
          ],
          selected: {s.riskMode},
          onSelectionChanged: (v) => s.setRiskMode(v.first),
        ),
        const SizedBox(height: 16),
        SwitchListTile(
          title: const Text("Auto-Trade (stub)"),
          value: s.autoTrade,
          onChanged: s.setAutoTrade,
        ),
        const Divider(),
        const Text("Strictness"),
        Slider(
          value: s.strictness,
          onChanged: s.setStrictness,
          min: 0,
          max: 1,
        ),
        Text("Current: ${(s.strictness * 100).toStringAsFixed(0)}%"),
      ],
    );
  }
}
