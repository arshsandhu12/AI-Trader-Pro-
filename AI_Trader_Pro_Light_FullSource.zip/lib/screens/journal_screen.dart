import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/journal_service.dart';

class JournalScreen extends StatelessWidget {
  const JournalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final journal = context.watch<JournalService>();
    return ListView.builder(
      itemCount: journal.trades.length,
      itemBuilder: (ctx, i) {
        final t = journal.trades[i];
        return ListTile(
          title: Text("${t['ticker']} ${t['direction']} @ ${t['entry'].toStringAsFixed(2)}"),
          subtitle: Text("SL ${t['stopLoss'].toStringAsFixed(2)} • TP ${t['takeProfit'].toStringAsFixed(2)} • ${t['timeframe']}"),
          trailing: Text(t['result'] ?? "-"),
        );
      },
    );
  }
}
