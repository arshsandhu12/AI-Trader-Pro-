import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/journal_service.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final journal = context.watch<JournalService>();
    final stats = journal.stats;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text("Win Rate: ${stats.winRate.toStringAsFixed(1)}%", style: const TextStyle(fontSize: 18)),
        const SizedBox(height: 8),
        Text("Avg R:R: ${stats.avgRR.toStringAsFixed(2)}"),
        const SizedBox(height: 8),
        Text("Total Trades: ${journal.trades.length}"),
      ],
    );
  }
}
