import 'package:flutter/material.dart';

class BacktesterScreen extends StatelessWidget {
  const BacktesterScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24.0),
        child: Text(
          "Backtester (light): Configure in Settings → then run scans to log results.
Full historical backtests build in desktop version.",
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
