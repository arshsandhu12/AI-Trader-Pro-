import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/signal_service.dart';

class SignalsScreen extends StatelessWidget {
  const SignalsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final svc = context.watch<SignalService>();
    return ListView.builder(
      itemCount: svc.signals.length,
      itemBuilder: (context, i) {
        final s = svc.signals[i];
        return ListTile(
          leading: Icon(s.direction == "BUY" ? Icons.arrow_upward : Icons.arrow_downward,
              color: s.direction == "BUY" ? Colors.greenAccent : Colors.redAccent),
          title: Text("${s.ticker} • ${s.timeframe} • ${s.direction}"),
          subtitle: Text("Entry: ${s.entry.toStringAsFixed(2)}  SL: ${s.stopLoss.toStringAsFixed(2)}  TP: ${s.takeProfit.toStringAsFixed(2)}"),
          trailing: Text("${s.confidence.toStringAsFixed(0)}%"),
        );
      },
    );
  }
}
