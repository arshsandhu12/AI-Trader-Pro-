import 'package:flutter/material.dart';
import 'chart_screen.dart';
import 'signals_screen.dart';
import 'backtester_screen.dart';
import 'dashboard_screen.dart';
import 'journal_screen.dart';
import 'ai_assistant_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _idx = 0;
  final screens = const [
    ChartScreen(),
    SignalsScreen(),
    BacktesterScreen(),
    DashboardScreen(),
    JournalScreen(),
    AIAssistantScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: screens[_idx]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _idx,
        onDestinationSelected: (i) => setState(() => _idx = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.show_chart), label: "Chart"),
          NavigationDestination(icon: Icon(Icons.bolt), label: "Signals"),
          NavigationDestination(icon: Icon(Icons.history), label: "Backtest"),
          NavigationDestination(icon: Icon(Icons.dashboard), label: "Dashboard"),
          NavigationDestination(icon: Icon(Icons.book), label: "Journal"),
          NavigationDestination(icon: Icon(Icons.smart_toy), label: "AI"),
          NavigationDestination(icon: Icon(Icons.settings), label: "Settings"),
        ],
      ),
    );
  }
}
