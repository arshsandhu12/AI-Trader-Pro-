import 'package:flutter/material.dart';

class AIAssistantScreen extends StatelessWidget {
  const AIAssistantScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.all(24.0),
      child: Text(
        "AI Assistant (light): Explains signals & risk ideas.
Full chat + LLM integrations are part of the desktop/full build.",
        textAlign: TextAlign.center,
      ),
    );
  }
}
