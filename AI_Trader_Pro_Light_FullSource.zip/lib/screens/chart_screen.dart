import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';
import '../services/signal_service.dart';
import '../widgets/signal_legend.dart';

class ChartScreen extends StatelessWidget {
  const ChartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final signals = context.watch<SignalService>();
    final data = signals.currentSeries;
    final markers = signals.currentMarkers;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12.0),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: signals.tickerController,
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(
                    hintText: "Ticker (e.g., AAPL, BTCUSD)",
                    hintStyle: TextStyle(color: Colors.white54),
                    border: OutlineInputBorder(),
                  ),
                  onSubmitted: (v) => signals.loadData(),
                ),
              ),
              const SizedBox(width: 8),
              DropdownButton<String>(
                value: signals.timeframe,
                onChanged: (v) => signals.setTimeframe(v!),
                items: const [
                  DropdownMenuItem(value: "1m", child: Text("1m")),
                  DropdownMenuItem(value: "5m", child: Text("5m")),
                  DropdownMenuItem(value: "15m", child: Text("15m")),
                  DropdownMenuItem(value: "1h", child: Text("1h")),
                  DropdownMenuItem(value: "4h", child: Text("4h")),
                  DropdownMenuItem(value: "1d", child: Text("1d")),
                ],
              ),
              const SizedBox(width: 8),
              FilledButton(
                onPressed: () => signals.scanAndSignal(),
                child: const Text("Scan"),
              ),
            ],
          ),
        ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: LineChart(LineChartData(
              gridData: const FlGridData(show: false),
              titlesData: const FlTitlesData(show: false),
              borderData: FlBorderData(show: true, border: const Border.fromBorderSide(BorderSide(color: Colors.white24))),
              lineBarsData: [
                LineChartBarData(
                  spots: [
                    for (var i = 0; i < data.length; i++)
                      FlSpot(i.toDouble(), data[i]),
                  ],
                  isCurved: true,
                  barWidth: 2,
                  dotData: const FlDotData(show: false),
                ),
              ],
              extraLinesData: ExtraLinesData(
                horizontalLines: [
                  ...markers.map((m) => HorizontalLine(
                        y: m.level,
                        color: m.color,
                        strokeWidth: 1.5,
                        dashArray: m.dash,
                        label: HorizontalLineLabel(
                          show: true,
                          alignment: Alignment.centerRight,
                          style: TextStyle(color: m.color, fontSize: 10),
                          labelResolver: (_) => m.label,
                        ),
                      )),
                ],
              ),
            )),
          ),
        ),
        const SignalLegend(),
      ],
    );
  }
}
