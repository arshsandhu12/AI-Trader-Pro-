# AI Trader Pro (Light Build)

This repo is phone-friendly and includes a GitHub Actions workflow to build a **Debug APK** in the cloud.

## Phone-only steps to get the APK
1. Open GitHub in Chrome on your phone → create a **public repo**.
2. Upload **all files** from this folder (keep the folder structure).
3. Go to **Actions** tab → enable workflows if prompted.
4. Run the workflow **Build Android APK**.
5. When it finishes, download the artifact **ai-trader-pro-debug-apk** → `app-debug.apk`.
6. Install the APK on your phone (allow unknown sources if asked).

## Features (light build)
- Basic chart (FL Chart)
- Buy/Sell signals with Entry/SL/TP drawn on chart
- Signals persist in local storage (journal)
- Notifications hooks (stubbed)
- Settings: Safe / Balanced / Risk; Auto-Trade toggle (stubbed executor)
- Backtester and performance dashboard stubs
- TradingView embed (WebView) placeholder for later upgrade

> For full features (brokers, TV indicators, options chain), extend the services in `lib/services/`.
